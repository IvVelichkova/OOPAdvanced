﻿namespace _06.Birthday_Celebrations.Models
{
    public interface IBirthable
    {
        string Name { get; }

        string BirthDate { get; }
    }
}

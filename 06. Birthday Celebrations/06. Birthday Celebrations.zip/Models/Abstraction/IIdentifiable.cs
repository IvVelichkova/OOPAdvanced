﻿namespace _06.Birthday_Celebrations.Models
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}

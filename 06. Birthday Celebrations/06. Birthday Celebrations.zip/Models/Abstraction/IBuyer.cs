﻿namespace _06.Birthday_Celebrations.Models.Abstraction
{
    public interface IBuyer
    {
        int Food { get; }

        void BuyFood();
    }
}

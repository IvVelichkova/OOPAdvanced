﻿namespace _06.Birthday_Celebrations.Models
{
    using Abstraction;

    public class Pet : LivingBeing
    {
        public Pet(string birthDate, string name) : base(birthDate, name)
        {
        }
    }
}

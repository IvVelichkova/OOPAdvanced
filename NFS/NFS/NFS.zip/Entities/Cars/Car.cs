﻿
public abstract class Car
{
}


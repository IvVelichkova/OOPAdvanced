﻿
public class DriftRace : Race
{
}


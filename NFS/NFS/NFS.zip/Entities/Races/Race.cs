﻿
public abstract class Race
{
}


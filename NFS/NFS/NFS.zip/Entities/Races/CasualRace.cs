﻿
public class CasualRace : Race
{
}


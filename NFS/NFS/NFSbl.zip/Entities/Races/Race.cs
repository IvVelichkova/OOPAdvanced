﻿
using System.Collections.Generic;

public abstract class Race
{

    /// <summary>
    /// length (int), route (string), a prizePool (int), and participants (Collection of Cars), 
    /// </summary>
    private int lenght;

    private string route;

    private int prizePool;

    private List<Car> participants;

    public Race(int lenght,string route,int prizePool)
    {
        this.Route = route;
        this.Lenght = lenght;
        this.PrizePool = prizePool;
        this.participants = new List<Car>();
    }
    public int Lenght  { get; set; }
public string Route { get; set; }
    public int PrizePool { get; set; }
    public List<Car> Participants { get; set; }

    
}


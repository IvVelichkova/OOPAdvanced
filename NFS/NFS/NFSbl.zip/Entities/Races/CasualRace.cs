﻿
public class CasualRace : Race
{
    public CasualRace(int lenght, string route, int prizePool) : base(lenght, route, prizePool)
    {
    }
}


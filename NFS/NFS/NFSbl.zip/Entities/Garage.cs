﻿
public class Garage
{
}


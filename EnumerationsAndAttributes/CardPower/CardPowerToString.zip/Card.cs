﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardPower
{
    public class Card

    {
        CardRank cardRank;
        Suit suitCard;

        public Card(CardRank cardRank,Suit suitCard)
        {
           this. SuitCard = suitCard;
            this.CardRanks = cardRank;
        }

        public CardRank CardRanks
        {
            get { return this.cardRank; }
            set { this.cardRank = value; }
        }


        public Suit SuitCard
        {
            get
            {
                return this.suitCard; 
                
            }
            set { this.suitCard = value; }
        }

       
        public override string ToString()
        {
            return
                $"Card name: {this.CardRanks} of {this.SuitCard}; Card power: {(int)SuitCard+(int)CardRanks}";
        }

        



    }
}

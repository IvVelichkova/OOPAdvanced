﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardPower
{
    class Program
    {
        static void Main(string[] args)
        {
            CardRank cardR;
            Suit suitC;
            var rank = Console.ReadLine();
            cardR=(CardRank)Enum.Parse(typeof(CardRank), rank);
            var suit = Console.ReadLine();
            suitC = (Suit)Enum.Parse(typeof(Suit), suit);
            Card card = new Card(cardR,suitC);
            Console.WriteLine(card.ToString());
        }

       
    }
}

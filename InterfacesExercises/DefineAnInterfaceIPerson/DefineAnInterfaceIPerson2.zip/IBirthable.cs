﻿using System;
public interface IBirthable
{
    //IBirthable with a string property Birthdate
    string Birthdate { get; }
}


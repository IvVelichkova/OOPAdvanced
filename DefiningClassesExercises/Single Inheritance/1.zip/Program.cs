﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Single_Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            var dog = new Dog();
            dog.Bark();
            dog.Eat();
        }
    }
}

﻿public class Program
{
    static void Main(string[] args)
    {
        var DOG = new Dog();
        DOG.Eat();
        DOG.Bark();

        var cat = new Cat();
        cat.Eat();
        cat.Meow();
    }
}


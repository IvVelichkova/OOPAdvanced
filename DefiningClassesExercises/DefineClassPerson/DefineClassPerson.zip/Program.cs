﻿using System;
using System.Reflection;

namespace DefineClassPerson
{
    public class Program
    {

        static void Main(string[] args)
        {
            Type personType = typeof(Person);
            FieldInfo[] fields = personType.GetFields(BindingFlags.Public | BindingFlags.Instance);
            Console.WriteLine(fields.Length);
            var p = new Person("Ivan", 23);
        }

    }
}

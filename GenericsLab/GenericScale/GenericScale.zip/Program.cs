﻿using System;
public class Program
{
    static void Main(string[] args)
    {


       
        //Console.WriteLine(new Scale<int>(1,1).getHeavier(1,1));
    }
}


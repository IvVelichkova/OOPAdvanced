﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Program
    {
        static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());
            List<Box<string>> listOfBox = new List<Box<string>>();

            for (int i = 0; i < n; i++)
            {
                Box<string> boxstr = new Box<string>(Console.ReadLine());
                listOfBox.Add(boxstr);
            }
            var indexes = Console.ReadLine().Split().Select(int.Parse).ToArray();
            SwapElemens( listOfBox, indexes[0], indexes[1]);

            foreach (var box in listOfBox )
            {
                Console.WriteLine(box);
            }
    }
       

    private static void SwapElemens<T>(List<Box<T>> listOfBox, int index1, int index2)
    {
       Box<T> tempElemnt = listOfBox[index1];
        listOfBox[index1] = listOfBox[index2];
        listOfBox[index2] = tempElemnt;

    }
}


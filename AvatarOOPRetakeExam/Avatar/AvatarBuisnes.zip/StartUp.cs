﻿using System;

public class StartUp

{
    public static void Main(string[] args)
    {
        var engin = new Engine();
        engin.Run();
    }
}


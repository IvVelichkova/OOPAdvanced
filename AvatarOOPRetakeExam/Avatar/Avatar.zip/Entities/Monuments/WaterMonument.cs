﻿public class WaterMonument:Monument
{
    public WaterMonument(string name) : base(name)
    {
    }
}


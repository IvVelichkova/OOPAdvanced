﻿public class FireMonument:Monument
{
    public FireMonument(string name) : base(name)
    {
    }
}


﻿public class AirMonument:Monument
{
    public AirMonument(string name) : base(name)
    {
    }
}


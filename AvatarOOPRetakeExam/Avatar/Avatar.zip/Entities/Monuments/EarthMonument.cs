﻿public class EarthMonument:Monument
{
    public EarthMonument(string name) : base(name)
    {
    }
}


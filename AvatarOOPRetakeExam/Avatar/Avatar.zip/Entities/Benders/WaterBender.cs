﻿using System;

public class WaterBender : Bender
{
    public WaterBender(string name, int power) : base(name, power)
    {
    }
}

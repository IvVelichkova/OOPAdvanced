﻿class EarthBender:Bender
{
    public EarthBender(string name, int power) : base(name, power)
    {
    }
}


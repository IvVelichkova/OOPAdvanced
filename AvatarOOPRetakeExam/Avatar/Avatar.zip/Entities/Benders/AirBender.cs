﻿using System;

public class AirBender:Bender
{
    public AirBender(string name, int power) : base(name, power)
    {
    }
}


﻿
public class FireBender:Bender
{
    public FireBender(string name, int power) : base(name, power)
    {
    }
}

